package com.github.catvod.crawler;

public class SpiderNull extends Spider {
}
